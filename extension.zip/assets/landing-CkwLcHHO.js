const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/drive-Cib940-e.js","assets/drive-BhGEDik0.css"])))=>i.map(i=>d[i]);
import{r as P,m as A,a as $,B as k,c as C,o as b,h as _,n as q,k as x,u as N,d as H}from"./drive-Cib940-e.js";import{r as j,g as O,o as M,e as z,f as G,c as U,a as R}from"./sync-DJ4wUDyq.js";const W="modulepreload",J=function(t){return"/"+t},I={},F=function(a,e,n){let o=Promise.resolve();if(e&&e.length>0){let l=function(s){return Promise.all(s.map(d=>Promise.resolve(d).then(u=>({status:"fulfilled",value:u}),u=>({status:"rejected",reason:u}))))};document.getElementsByTagName("link");const c=document.querySelector("meta[property=csp-nonce]"),h=(c==null?void 0:c.nonce)||(c==null?void 0:c.getAttribute("nonce"));o=l(e.map(s=>{if(s=J(s),s in I)return;I[s]=!0;const d=s.endsWith(".css"),u=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${s}"]${u}`))return;const i=document.createElement("link");if(i.rel=d?"stylesheet":W,d||(i.as="script"),i.crossOrigin="",i.href=s,h&&i.setAttribute("nonce",h),document.head.appendChild(i),d)return new Promise((g,m)=>{i.addEventListener("load",g),i.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${s}`)))})}))}function r(l){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=l,window.dispatchEvent(c),!c.defaultPrevented)throw l}return o.then(l=>{for(const c of l||[])c.status==="rejected"&&r(c.reason);return a().catch(r)})};async function V(){await P();const t=await A();document.documentElement.style.setProperty("--font-size",`${t.fontSize}px`),$(t.theme),k(t.theme,e=>{document.documentElement.setAttribute("data-theme",e)}),await j().catch(()=>{}),chrome.runtime.onMessage.addListener(e=>{if(e.type==="SETTINGS_CHANGED"){const n=e.settings;document.documentElement.style.setProperty("--font-size",`${n.fontSize}px`),$(n.theme)}e.type==="OPEN_DOCS_CHANGED"&&y().catch(console.error)}),document.getElementById("btn-new").addEventListener("click",()=>{const e=C();window.location.href=`editor.html?docId=${e.id}&new=1`}),await y(),Q();const a=await b();await K(a),a&&T()}async function K(t){const a=document.getElementById("settings-badge"),e=document.getElementById("btn-settings");if(!a||!e)return;const n=t??await b(),{deviceName:o}=await q();n&&!o?(a.classList.remove("hidden"),e.title="設定 ⚠ デバイス名が未設定です"):(a.classList.add("hidden"),e.title="設定")}function Q(){const t=document.getElementById("btn-sync"),a=document.getElementById("sync-status"),e=n=>{a.className=`sync-status sync-${n}`;const o={idle:"同期済み",syncing:"同期中...",error:"同期エラー",conflict:"競合あり"};a.title=o[n]??""};e(R()),M(e),t.addEventListener("click",async()=>{if(!await b()){X("Google Drive が未接続です。設定から接続してください。","settings.html");return}T()})}let v=null;function X(t,a){const e=document.getElementById("landing-toast");e&&e.remove(),v&&clearTimeout(v);const n=document.createElement("div");n.id="landing-toast",n.className="landing-toast",n.innerHTML=`${t} <a href="${a}">設定を開く</a>`,document.body.appendChild(n),v=setTimeout(()=>{n.classList.add("toast-fade-out"),setTimeout(()=>n.remove(),300)},4e3)}async function T(){const t=await z();t.pulled>0&&await y();for(const a of t.conflicts)await Y(a)}function Y(t){return new Promise(a=>{const e=document.getElementById("conflict-modal"),n=document.getElementById("conflict-local-meta"),o=document.getElementById("conflict-remote-meta"),r=document.getElementById("conflict-local-preview"),l=document.getElementById("conflict-remote-preview"),c=s=>new Date(s).toLocaleString("ja-JP");n.textContent=`${c(t.local.updatedAt)} · ${t.local.charCount}文字`,o.textContent=`${t.remote.deviceName} · ${c(t.remote.updatedAt)} · ${t.remote.charCount}文字`,r.textContent=t.local.content.slice(0,300),l.textContent=t.remote.content.slice(0,300),e.classList.remove("hidden");const h=async s=>{e.classList.add("hidden"),await U(t,s),await y(),a()};e.querySelectorAll("[data-choice]").forEach(s=>{s.onclick=()=>h(s.dataset.choice)})})}async function y(){var n;const t=document.getElementById("doc-list"),[a,e]=await Promise.all([_(),O().catch(()=>({}))]);if(a.length===0){t.innerHTML=`
      <div class="empty-state">
        <p>まだドキュメントがありません</p>
        <button class="primary" id="btn-new-empty">+ 新規ドキュメントを作成</button>
      </div>
    `,(n=document.getElementById("btn-new-empty"))==null||n.addEventListener("click",()=>{const o=C();window.location.href=`editor.html?docId=${o.id}&new=1`});return}t.innerHTML="";for(const o of a){const r=Z(o,e);t.appendChild(r)}}function Z(t,a){var s,d,u;const e=a[t.id],n=e!=null,o=document.createElement("div");o.className="doc-item",o.dataset.docId=t.id;const r=x(t.content),l=new Date(t.updatedAt).toLocaleString("ja-JP",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}),c=n?'<span class="doc-open-badge">他のタブで開いています</span>':"";return o.innerHTML=`
    <div class="doc-info">
      <input
        type="text"
        class="doc-title-input"
        value="${L(r)}"
        data-doc-id="${t.id}"
        data-original="${L(r)}"
        aria-label="ドキュメントタイトル"
      />
      <div class="doc-meta">
        <span>${l}</span>
        ${c}
      </div>
    </div>
    <div class="doc-actions">
      ${n?`<button class="btn-focus" data-tab-id="${e}">タブを表示</button>`:""}
      ${n?"":`<button class="btn-open" data-doc-id="${t.id}">開く</button>`}
      <button class="btn-delete" data-doc-id="${t.id}" title="削除">✕</button>
    </div>
  `,o.querySelector(".doc-title-input").addEventListener("change",async i=>{var S;const g=i.currentTarget,m=g.value.trim();if(!m){g.value=g.dataset.original??"無題";return}const p=await F(()=>import("./drive-Cib940-e.js").then(f=>f.y),__vite__mapDeps([0,1])).then(f=>f.getDoc(t.id));if(!p)return;const E=p.content.split(`
`)[0],D=/^#+/.test(E);let w;if(D){const f=((S=E.match(/^(#+\s*)/))==null?void 0:S[1])??"# ",B=p.content.split(`
`).slice(1).join(`
`);w=`${f}${m}
${B}`}else if(E==="")w=`# ${m}
${p.content}`;else{const f=p.content.split(`
`).slice(1).join(`
`);w=`${m}
${f}`}await N({...p,content:w,updatedAt:Date.now()}),g.dataset.original=m}),(s=o.querySelector(".btn-open"))==null||s.addEventListener("click",()=>{window.location.href=`editor.html?docId=${t.id}`}),(d=o.querySelector(".btn-focus"))==null||d.addEventListener("click",async()=>{const i=parseInt(o.querySelector(".btn-focus").dataset.tabId??"0",10);await G(i).catch(()=>{})}),(u=o.querySelector(".btn-delete"))==null||u.addEventListener("click",async()=>{if(!confirm(`"${r}" を削除しますか？`))return;await H(t.id),o.remove(),document.getElementById("doc-list").children.length===0&&await y()}),o}function L(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}V().catch(console.error);
